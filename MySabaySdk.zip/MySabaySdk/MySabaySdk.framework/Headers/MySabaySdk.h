//
//  MySabaySdk.h
//  MySabaySdk
//
//  Created by Lay Channara on 2/25/20.
//  Copyright © 2020 Sabay Digital Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MySabaySdk.
FOUNDATION_EXPORT double MySabaySdkVersionNumber;

//! Project version string for MySabaySdk.
FOUNDATION_EXPORT const unsigned char MySabaySdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySabaySdk/PublicHeader.h>


